import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {
        double p = 1.0;
        double i = 1.0;
        String result = "";
        while (!StdIn.isEmpty()) {
            String str = StdIn.readString();
            if (StdRandom.bernoulli(p))
                result = str;
            p = 1.0 / ++i;
        }
        StdOut.println(result);
    }
}