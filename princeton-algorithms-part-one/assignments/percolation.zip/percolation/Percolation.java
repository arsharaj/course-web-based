import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final WeightedQuickUnionUF uf;
    private final boolean[][] opened;
    private final int size;
    private final int top;
    private final int bottom;
    private int openedSites;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();
        size = n;
        top = 0;
        bottom = size * size + 1;
        uf = new WeightedQuickUnionUF(size * size + 2);
        opened = new boolean[size][size];
        openedSites = 0;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        checkException(row, col);

        if (isOpen(row, col)) return;

        opened[row - 1][col - 1] = true;
        ++openedSites;

        // case : top row
        if (row == 1)
            uf.union(getQuickFindIndex(row, col), top);

        // case : bottom row
        if (row == size)
            uf.union(getQuickFindIndex(row, col), bottom);

        // case : top element
        if (row > 1 && isOpen(row - 1, col))
            uf.union(getQuickFindIndex(row, col), getQuickFindIndex(row - 1, col));

        // case : bottom element
        if (row < size && isOpen(row + 1, col))
            uf.union(getQuickFindIndex(row, col), getQuickFindIndex(row + 1, col));

        // case : left element
        if (col > 1 && isOpen(row, col - 1))
            uf.union(getQuickFindIndex(row, col), getQuickFindIndex(row, col - 1));

        // case : right element
        if (col < size && isOpen(row, col + 1))
            uf.union(getQuickFindIndex(row, col), getQuickFindIndex(row, col + 1));
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        checkException(row, col);
        return opened[row - 1][col - 1];
    }

    // gives the mapped index for ufs
    private int getQuickFindIndex(int row, int col) {
        return size * (row - 1) + col;
    }

    // check valid row and cols
    private void checkException(int row, int col) {
        if (row < 1 || row > size || col < 1 || col > size)
            throw new IllegalArgumentException();
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openedSites;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        checkException(row, col);
        return uf.find(top) == uf.find(getQuickFindIndex(row, col));
    }

    // does the system percolate?
    public boolean percolates() {
        return uf.find(top) == uf.find(bottom);
    }
}